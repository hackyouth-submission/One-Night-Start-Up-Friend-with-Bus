class ImageConstant {
  static String imgImage1 = 'assets/images/img_image1.png';

  static String imgCheckmark = 'assets/images/img_checkmark.svg';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
