import 'package:flutter/material.dart';
import 'package:hong_s_application2/presentation/iphone_14_pro_two_screen/iphone_14_pro_two_screen.dart';

class AppRoutes {
  static const String iphone14ProTwoScreen = '/iphone_14_pro_two_screen';

  static Map<String, WidgetBuilder> routes = {
    iphone14ProTwoScreen: (context) => Iphone14ProTwoScreen()
  };
}
