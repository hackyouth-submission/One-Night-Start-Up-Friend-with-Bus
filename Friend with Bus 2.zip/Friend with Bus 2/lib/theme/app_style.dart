import 'package:flutter/material.dart';
import 'package:hong_s_application2/core/app_export.dart';

class AppStyle {
  static TextStyle txtRobotoRomanRegular15 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      15,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w400,
  );

  static TextStyle txtRobotoRomanBold30 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      30,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );

  static TextStyle txtRobotoRomanBold50 = TextStyle(
    color: ColorConstant.black900,
    fontSize: getFontSize(
      50,
    ),
    fontFamily: 'Roboto',
    fontWeight: FontWeight.w700,
  );
}
