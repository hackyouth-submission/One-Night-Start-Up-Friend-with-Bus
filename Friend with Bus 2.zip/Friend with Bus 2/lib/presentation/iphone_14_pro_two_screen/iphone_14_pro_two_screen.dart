import 'package:flutter/material.dart';
import 'package:Friend with Bus/core/app_export.dart';

class Iphone14ProTwoScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: ColorConstant.whiteA700,
        body: Container(
          width: double.maxFinite,
          padding: getPadding(
            left: 24,
            top: 57,
            right: 24,
            bottom: 57,
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Padding(
                padding: getPadding(
                  left: 48,
                ),
                child: Text(
                  "PAYMENT",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtRobotoRomanBold50,
                ),
              ),
              Padding(
                padding: getPadding(
                  left: 82,
                  top: 67,
                ),
                child: Text(
                  "NUMBER: 1",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtRobotoRomanBold30,
                ),
              ),
              Padding(
                padding: getPadding(
                  left: 42,
                  top: 59,
                ),
                child: Text(
                  "PRICE: 9.000 VND",
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtRobotoRomanBold30,
                ),
              ),
              Align(
                alignment: Alignment.center,
                child: Container(
                  height: getVerticalSize(
                    416,
                  ),
                  width: getHorizontalSize(
                    323,
                  ),
                  margin: getMargin(
                    top: 6,
                  ),
                  child: Stack(
                    alignment: Alignment.bottomLeft,
                    children: [
                      CustomImageView(
                        imagePath: ImageConstant.imgImage1,
                        height: getVerticalSize(
                          335,
                        ),
                        width: getHorizontalSize(
                          323,
                        ),
                        alignment: Alignment.topCenter,
                      ),
                      CustomImageView(
                        svgPath: ImageConstant.imgCheckmark,
                        height: getVerticalSize(
                          91,
                        ),
                        width: getHorizontalSize(
                          20,
                        ),
                        alignment: Alignment.bottomLeft,
                        margin: getMargin(
                          left: 76,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Container(
                width: getHorizontalSize(
                  234,
                ),
                margin: getMargin(
                  top: 5,
                  bottom: 5,
                ),
                child: Text(
                  "QR Code to verify and keep track of passenger buying ticket online",
                  maxLines: null,
                  textAlign: TextAlign.left,
                  style: AppStyle.txtRobotoRomanRegular15,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
