class ApiConstants {
  static const baseUrl = 'https://fruitcastle.onrender.com';
}